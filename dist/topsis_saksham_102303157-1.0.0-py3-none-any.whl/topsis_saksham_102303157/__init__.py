
from .topsis import topsis, main

__version__ = "1.0.0"
__author__ = "Saksham"
__email__ = "your.email@example.com"

__all__ = ['topsis', 'main']